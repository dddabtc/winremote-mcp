"""winremote-mcp: Windows Remote MCP Server."""

__version__ = "0.4.1"
